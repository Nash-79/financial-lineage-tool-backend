# Data Folder Structure

This folder contains all data processed by the Financial Data Lineage Tool, organized hierarchically by database/project name.

## Structure

```
data/
├── README.md                        # This file
├── .cache/                          # Global cache (parse results, etc.)
└── {database-name}/                 # One folder per database
    ├── raw/                         # Original SQL files
    ├── separated/                   # Separated SQL objects by type
    │   ├── tables/
    │   ├── views/
    │   ├── stored_procedures/
    │   ├── functions/
    │   ├── schemas/
    │   ├── indexes/
    │   ├── triggers/
    │   ├── unknown/
    │   └── separation_manifest.json
    ├── embeddings/                  # Vector embeddings
    │   ├── sql_embeddings.json
    │   ├── entity_embeddings.json
    │   └── sample_embeddings.json
    ├── graph/                       # Knowledge graph exports
    │   ├── graph_export.json
    │   ├── graph_viz.json
    │   └── cypher_queries.json
    └── metadata/                    # Processing metadata and logs
        ├── failed_ingestion.jsonl
        └── processing_stats.json
```

## Folder Purposes

### `{database-name}/`
Each database or project gets its own top-level folder. The database name is normalized to kebab-case for consistency:

- `AdventureWorksLT-All.sql` → `adventureworks-lt-all/`
- `sample_financial_schema` → `sample-financial-schema/`
- `MyDatabase` → `my-database/`

### `raw/`
Contains the original, unprocessed SQL files as they were ingested. These files are never modified.

**Example files:**
- `AdventureWorksLT-All.sql`
- `schema_dump.sql`

### `separated/`
Contains SQL objects extracted and organized by type. Each object type has its own subfolder.

**Subfolders:**
- `tables/` - Table definitions (CREATE TABLE statements)
- `views/` - View definitions (CREATE VIEW statements)
- `stored_procedures/` - Stored procedure definitions
- `functions/` - User-defined function definitions
- `schemas/` - Schema definitions (CREATE SCHEMA statements)
- `indexes/` - Index definitions (CREATE INDEX statements)
- `triggers/` - Trigger definitions
- `unknown/` - Objects that couldn't be classified

**Special files:**
- `separation_manifest.json` - Metadata about the separation process

### `embeddings/`
Contains vector embeddings generated from SQL code and entities.

**Files:**
- `sql_embeddings.json` - Embeddings of SQL code chunks
- `entity_embeddings.json` - Embeddings of database entities (tables, columns)
- `sample_embeddings.json` - Embeddings of sample data

### `graph/`
Contains knowledge graph exports from Neo4j and visualization data.

**Files:**
- `graph_export.json` - Full graph export (nodes and relationships)
- `graph_viz.json` - Graph visualization data (positions, layouts)
- `cypher_queries.json` - Generated Cypher queries for lineage

### `metadata/`
Contains processing logs, statistics, and error reports.

**Files:**
- `failed_ingestion.jsonl` - Log of files that failed to process
- `processing_stats.json` - Statistics about processing (time, counts, etc.)

## Naming Conventions

### Database Names
- Normalized to **kebab-case**
- Lowercase letters, numbers, and hyphens only
- No spaces, underscores, or special characters
- Leading/trailing hyphens removed

### File Names
- Original SQL files: Preserved as-is in `raw/`
- Separated objects: Named by object name (e.g., `Customer.sql`, `vw_SalesOrders.sql`)
- Embeddings/exports: Standard names as listed above

## Usage Examples

### Ingesting a New Database

```bash
# Ingest with explicit database name
python -m src.ingestion.batch_processor --file AdventureWorksLT.sql --database adventureworks-lt

# Database name auto-detected from filename
python -m src.ingestion.batch_processor --file AdventureWorksLT-All.sql
# Creates: data/adventureworks-lt-all/
```

### Finding Outputs

```bash
# All data for a specific database
ls data/my-database/

# SQL embeddings for a database
cat data/my-database/embeddings/sql_embeddings.json

# Separated table definitions
ls data/my-database/separated/tables/

# Graph export
cat data/my-database/graph/graph_export.json
```

### Multiple Databases

```bash
# Process multiple databases
data/
├── adventureworks-lt/
│   ├── raw/
│   ├── separated/
│   └── ...
├── northwind/
│   ├── raw/
│   ├── separated/
│   └── ...
└── sample-financial-schema/
    ├── raw/
    ├── separated/
    └── ...
```

## Migration from Old Structure

If you have data in the old flat structure, use the migration script:

```bash
# Dry run to see what would be moved
python scripts/migrate_data_structure.py --dry-run

# Execute migration with automatic backup
python scripts/migrate_data_structure.py --execute --backup

# Validate migration completed successfully
python scripts/migrate_data_structure.py --validate
```

## Cache Directory

The `.cache/` directory is global and contains:
- Parsed SQL AST cache (keyed by file content SHA-256)
- Other performance optimization caches

Cache files are safe to delete - they will be regenerated as needed.

## Best Practices

1. **Always specify database name** when ingesting new data (or ensure filename contains it)
2. **Don't manually edit files** in `separated/`, `embeddings/`, or `graph/` - they're auto-generated
3. **Keep raw files** - they're the source of truth
4. **Back up before major operations** - use `tar -czf backup.tar.gz data/`
5. **Use the migration script** when reorganizing existing data

## Troubleshooting

### Files in wrong location
Run the migration script to reorganize:
```bash
python scripts/migrate_data_structure.py --execute
```

### Database name not detected
Specify explicitly:
```bash
python -m src.ingestion.batch_processor --file myfile.sql --database my-database
```

### Missing folders
Folders are created automatically when needed. If you need to create the structure manually:
```bash
mkdir -p data/{database-name}/{raw,separated,embeddings,graph,metadata}
```
