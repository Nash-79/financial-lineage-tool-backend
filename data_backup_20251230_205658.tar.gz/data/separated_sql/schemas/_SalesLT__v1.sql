-- ============================================
-- Object Type: SCHEMA
-- Object Name: [SalesLT]
-- Source File: AdventureWorksLT-All.sql
-- Separated On: 2025-12-08 18:47:28
-- Dialect: tsql
-- ============================================

****** Object:  Schema [SalesLT]    Script Date: 4/7/2021 10:02:56 AM ******/
CREATE SCHEMA [SalesLT]
G
