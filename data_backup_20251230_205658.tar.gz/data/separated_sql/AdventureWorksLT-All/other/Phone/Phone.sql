-- ============================================
-- Object Type: Unknown
-- Object Name: [dbo].[Phone]
-- Source File: AdventureWorksLT-All.sql
-- Script Date: 4/7/2021 10:02:56 AM
-- Separated On: 2025-12-08 20:25:14
-- ============================================

CREATE TYPE [dbo].[Phone] FROM [nvarchar](25) NULL
GO
