-- ============================================
-- Object Type: Unknown
-- Object Name: [dbo].[Name]
-- Source File: AdventureWorksLT-All.sql
-- Script Date: 4/7/2021 10:02:56 AM
-- Separated On: 2025-12-08 20:25:14
-- ============================================

CREATE TYPE [dbo].[Name] FROM [nvarchar](50) NULL
GO
