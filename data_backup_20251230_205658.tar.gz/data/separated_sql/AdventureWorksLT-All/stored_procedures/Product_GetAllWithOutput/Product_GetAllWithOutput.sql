-- ============================================
-- Object Type: StoredProcedure
-- Object Name: [SalesLT].[Product_GetAllWithOutput]
-- Source File: AdventureWorksLT-All.sql
-- Script Date: 4/7/2021 10:02:56 AM
-- Separated On: 2025-12-08 20:25:14
-- ============================================

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [SalesLT].[Product_GetAllWithOutput]
	@Test nvarchar(10) OUTPUT
AS
BEGIN
	SELECT *
	FROM SalesLT.Product;

	SELECT @Test = 'Hello';
END
GO
