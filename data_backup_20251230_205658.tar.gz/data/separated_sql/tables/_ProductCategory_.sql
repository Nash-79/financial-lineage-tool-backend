-- ============================================
-- Object Type: TABLE
-- Object Name: [SalesLT].[ProductCategory]
-- Source File: AdventureWorksLT-All.sql
-- Separated On: 2025-12-08 18:47:03
-- Dialect: tsql
-- ============================================

om/sqlserver/2004/07/adventure-works/ProductModelDescription";
