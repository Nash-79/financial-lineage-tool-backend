-- ============================================
-- Object Type: TABLE
-- Object Name: [SalesLT].[ProductModelProductDescription]
-- Source File: AdventureWorksLT-All.sql
-- Separated On: 2025-12-08 18:47:28
-- Dialect: tsql
-- ============================================

oductDescription_rowguid] UNIQUE NONCLUSTERED 
(
	[rowguid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
G
