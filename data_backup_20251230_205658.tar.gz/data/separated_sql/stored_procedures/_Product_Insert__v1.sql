-- ============================================
-- Object Type: PROCEDURE
-- Object Name: [SalesLT].[Product_Insert]
-- Source File: AdventureWorksLT-All.sql
-- Separated On: 2025-12-08 18:47:28
-- Dialect: tsql
-- ============================================

nt]>=(0.00)))
G
