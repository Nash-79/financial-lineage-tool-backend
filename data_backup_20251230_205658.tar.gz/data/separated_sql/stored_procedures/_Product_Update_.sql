-- ============================================
-- Object Type: PROCEDURE
-- Object Name: [SalesLT].[Product_Update]
-- Source File: AdventureWorksLT-All.sql
-- Separated On: 2025-12-08 18:47:03
-- Dialect: tsql
-- ============================================

e: 4/7/2021 10:02:56 AM ******/
SET ANSI_NULLS ON
G
