-- ============================================
-- Object Type: PROCEDURE
-- Object Name: [SalesLT].[Product_GetAllWithOutput]
-- Source File: AdventureWorksLT-All.sql
-- Separated On: 2025-12-08 18:47:03
-- Dialect: tsql
-- ============================================

.[SalesOrderDetail] CHECK CONSTRAINT [CK_SalesOrderDetail_UnitPrice]
G
