-- ============================================
-- Object Type: PROCEDURE
-- Object Name: [SalesLT].[MultipleResults]
-- Source File: AdventureWorksLT-All.sql
-- Separated On: 2025-12-08 18:47:28
-- Dialect: tsql
-- ============================================

der] CHECK CONSTRAINT [FK_SalesOrderHeader_Address_BillTo_AddressID]
G
