-- ============================================
-- Object Type: PROCEDURE
-- Object Name: [SalesLT].[Product_UpdateListPrice]
-- Source File: AdventureWorksLT-All.sql
-- Separated On: 2025-12-08 18:47:28
-- Dialect: tsql
-- ============================================

****/
SET ANSI_NULLS ON
G
