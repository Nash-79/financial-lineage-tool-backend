-- ============================================
-- Object Type: PROCEDURE
-- Object Name: [SalesLT].[Product_Delete]
-- Source File: AdventureWorksLT-All.sql
-- Separated On: 2025-12-08 18:47:03
-- Dialect: tsql
-- ============================================

ECK ADD  CONSTRAINT [CK_Product_Weight] CHECK  (([Weight]>(0.00)))
G
