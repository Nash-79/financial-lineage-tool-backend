-- ============================================
-- Object Type: PROCEDURE
-- Object Name: [SalesLT].[SalesOrderDetail_GetBySalesOrderIDs]
-- Source File: AdventureWorksLT-All.sql
-- Separated On: 2025-12-08 18:47:28
-- Dialect: tsql
-- ============================================

duct 
    WHERE ProductID = @ProductID
END
G
